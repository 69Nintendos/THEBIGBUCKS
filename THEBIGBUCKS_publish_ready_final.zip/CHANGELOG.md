# Changelog

## v2.2a — QMXAI LOTTO MAX ADVANCED
- Demo prints mains + bonus
- PRO engine room sealed (obfuscated runtime loader)
- Embedded testimonies (Vigenère)
- README/license polish
- Added `examples/` folder
